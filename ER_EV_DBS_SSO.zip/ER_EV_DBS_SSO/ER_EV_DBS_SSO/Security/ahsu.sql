﻿CREATE USER [ahsu] FOR LOGIN [ahsu];

