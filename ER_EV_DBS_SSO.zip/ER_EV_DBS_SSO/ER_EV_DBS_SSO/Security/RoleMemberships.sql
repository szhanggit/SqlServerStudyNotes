﻿ALTER ROLE [db_owner] ADD MEMBER [ER_EV_DBS_SSO];


GO
ALTER ROLE [db_datareader] ADD MEMBER [ahsu];


GO
ALTER ROLE [db_datareader] ADD MEMBER [GOLD\adm-ishuang];


GO
ALTER ROLE [db_datareader] ADD MEMBER [GOLD\adm-hwu];


GO
ALTER ROLE [db_datareader] ADD MEMBER [GOLD\adm-jhsu];


GO
ALTER ROLE [db_datareader] ADD MEMBER [GOLD\adm-eliao];


GO
ALTER ROLE [db_datareader] ADD MEMBER [GOLD\adm-bbai];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [GOLD\adm-jhsu];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [GOLD\adm-eliao];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [GOLD\adm-bbai];

