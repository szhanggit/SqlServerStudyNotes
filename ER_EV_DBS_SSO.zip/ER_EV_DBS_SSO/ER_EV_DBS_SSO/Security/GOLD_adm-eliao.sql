﻿CREATE USER [GOLD\adm-eliao] FOR LOGIN [GOLD\adm-eliao];

