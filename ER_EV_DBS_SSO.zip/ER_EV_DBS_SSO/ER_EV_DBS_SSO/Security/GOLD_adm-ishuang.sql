﻿CREATE USER [GOLD\adm-ishuang] FOR LOGIN [GOLD\adm-ishuang];

