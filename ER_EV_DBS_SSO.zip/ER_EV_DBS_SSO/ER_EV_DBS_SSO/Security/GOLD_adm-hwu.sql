﻿CREATE USER [GOLD\adm-hwu] FOR LOGIN [GOLD\adm-hwu];

