﻿CREATE USER [GOLD\adm-jhsu];

