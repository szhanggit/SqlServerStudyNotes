﻿CREATE USER [GOLD\adm-bbai] FOR LOGIN [GOLD\adm-bbai];

