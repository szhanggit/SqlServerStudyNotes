﻿

CREATE PROCEDURE uspCreateRevision
	@Revision INT,
	@Action NVARCHAR(200),
	@UserId INT = NULL,
	@Comment NVARCHAR(2000) = NULL,
	@ForceUpdate BIT = 0
AS
BEGIN

	PRINT 'Starting update revision...'

	-- get previous revision
	DECLARE @PreviousRevision INT
	
	IF EXISTS (SELECT 1 FROM dbo.Revision)
	BEGIN
		SELECT TOP 1 @PreviousRevision = Revision FROM dbo.Revision ORDER BY [TimeStamp] DESC
	END
	ELSE
	BEGIN
		SELECT @PreviousRevision = 0
	END
	
	PRINT 'Previous revision:' + CAST(@PreviousRevision AS NVARCHAR(20))
	PRINT 'Target revision:' + CAST(@Revision AS NVARCHAR(20))
	
	--check revision
	IF( @ForceUpdate <> 1 AND @PreviousRevision + 1 <> @Revision )
	BEGIN
		RAISERROR ('[ERROR] Revision is not sequential.' , -- Message text.
           16, -- Severity.
           1 -- State.
           );
          
        RETURN -1
	END
	
	--update revision
	
	INSERT INTO dbo.Revision
	        ( UserId ,
	          Revision ,
	          PreviousRevision ,
	          Action ,
	          TimeStamp ,
	          Comment
	        )
	VALUES  ( @UserId , -- UserId - int
	          @Revision , -- Revision - int
	          @PreviousRevision , -- PreviousRevision - int
	          @Action , -- Action - nvarchar(200)
	          GETDATE() , -- TimeStamp - datetime
	          @Comment  -- Comment - nvarchar(2000)
	        )	
	
	--print result
	
	PRINT 'Revision updated, latest is:' + CAST(@Revision AS NVARCHAR(20))
	RETURN 0
END
