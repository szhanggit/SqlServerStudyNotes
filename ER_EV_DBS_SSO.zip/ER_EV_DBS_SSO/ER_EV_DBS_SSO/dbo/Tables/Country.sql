﻿CREATE TABLE [dbo].[Country] (
    [Id]            INT            IDENTITY (1, 1) NOT NULL,
    [Name]          NVARCHAR (200) NULL,
    [TranslationId] INT            NULL,
    CONSTRAINT [PK_COUNTRY] PRIMARY KEY CLUSTERED ([Id] ASC)
);


GO
CREATE NONCLUSTERED INDEX [Index_Id]
    ON [dbo].[Country]([Id] ASC);

