﻿CREATE TABLE [dbo].[Revision] (
    [Id]               INT             IDENTITY (1, 1) NOT NULL,
    [UserId]           INT             NULL,
    [Revision]         INT             NOT NULL,
    [PreviousRevision] INT             NOT NULL,
    [Action]           NVARCHAR (200)  NOT NULL,
    [TimeStamp]        DATETIME        NOT NULL,
    [Comment]          NVARCHAR (2000) NULL,
    CONSTRAINT [PK_REVISION] PRIMARY KEY CLUSTERED ([Id] ASC)
);

