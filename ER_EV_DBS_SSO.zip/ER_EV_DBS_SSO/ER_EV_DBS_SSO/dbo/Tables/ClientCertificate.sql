﻿CREATE TABLE [dbo].[ClientCertificate] (
    [Id]          INT            IDENTITY (1, 1) NOT NULL,
    [UserName]    NVARCHAR (200) NOT NULL,
    [Thumbprint]  NVARCHAR (500) NOT NULL,
    [Description] NVARCHAR (500) NULL,
    CONSTRAINT [PK_CLIENTCERTIFICATE] PRIMARY KEY CLUSTERED ([Id] ASC)
);

