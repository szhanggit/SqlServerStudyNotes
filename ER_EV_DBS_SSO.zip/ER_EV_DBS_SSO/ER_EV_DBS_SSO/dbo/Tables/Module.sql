﻿CREATE TABLE [dbo].[Module] (
    [Id]          INT             IDENTITY (1, 1) NOT NULL,
    [Name]        NVARCHAR (200)  NOT NULL,
    [DisplayName] NVARCHAR (200)  NOT NULL,
    [Description] NVARCHAR (2000) NULL,
    [AppId]       INT             NOT NULL,
    CONSTRAINT [PK_MODULE] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_MODULE_REFERENCE_APP] FOREIGN KEY ([AppId]) REFERENCES [dbo].[App] ([Id])
);

