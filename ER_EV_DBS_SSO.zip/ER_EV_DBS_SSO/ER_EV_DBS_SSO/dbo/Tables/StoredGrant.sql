﻿CREATE TABLE [dbo].[StoredGrant] (
    [Id]                     INT             IDENTITY (1, 1) NOT NULL,
    [GrantId]                NVARCHAR (50)   NOT NULL,
    [GrantType]              INT             NOT NULL,
    [Subject]                NVARCHAR (200)  NOT NULL,
    [Scopes]                 NVARCHAR (200)  NOT NULL,
    [ClientId]               NVARCHAR (200)  NOT NULL,
    [Created]                DATETIME        NOT NULL,
    [Expiration]             DATETIME        NOT NULL,
    [RefreshTokenExpiration] DATETIME        NULL,
    [RedirectUri]            NVARCHAR (1000) NULL,
    CONSTRAINT [PK_STOREDGRANT] PRIMARY KEY CLUSTERED ([Id] ASC)
);

