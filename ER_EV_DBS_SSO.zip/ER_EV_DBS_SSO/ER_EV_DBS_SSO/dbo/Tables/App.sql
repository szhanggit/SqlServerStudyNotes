﻿CREATE TABLE [dbo].[App] (
    [Id]                     INT             IDENTITY (1, 1) NOT NULL,
    [Name]                   NVARCHAR (200)  NOT NULL,
    [DisplayName]            NVARCHAR (200)  NOT NULL,
    [Key]                    NVARCHAR (1000) NOT NULL,
    [Description]            NVARCHAR (2000) NOT NULL,
    [Enabled]                BIT             NOT NULL,
    [EnableAutoCreateADUser] BIT             DEFAULT ((0)) NOT NULL,
    [ADUserDefaultRoles]     NVARCHAR (500)  NULL,
    CONSTRAINT [PK_APP] PRIMARY KEY CLUSTERED ([Id] ASC)
);

