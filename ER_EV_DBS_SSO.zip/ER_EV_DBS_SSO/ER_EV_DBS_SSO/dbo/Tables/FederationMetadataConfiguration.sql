﻿CREATE TABLE [dbo].[FederationMetadataConfiguration] (
    [Id]      INT IDENTITY (1, 1) NOT NULL,
    [Enabled] BIT NOT NULL,
    CONSTRAINT [PK_FEDERATIONMETADATACONFIGURA] PRIMARY KEY CLUSTERED ([Id] ASC)
);

