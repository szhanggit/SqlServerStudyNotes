﻿CREATE TABLE [dbo].[Delegation] (
    [Id]          INT            IDENTITY (1, 1) NOT NULL,
    [UserName]    NVARCHAR (200) NOT NULL,
    [Realm]       NVARCHAR (200) NOT NULL,
    [Description] NVARCHAR (500) NULL,
    CONSTRAINT [PK_DELEGATION] PRIMARY KEY CLUSTERED ([Id] ASC)
);

