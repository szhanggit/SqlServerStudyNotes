﻿CREATE TABLE [dbo].[GlobalConfiguration] (
    [Id]                                    INT            IDENTITY (1, 1) NOT NULL,
    [SiteName]                              NVARCHAR (200) NOT NULL,
    [IssuerUri]                             NVARCHAR (500) NOT NULL,
    [IssuerContactEmail]                    NVARCHAR (200) NOT NULL,
    [DefaultWSTokenType]                    NVARCHAR (100) NOT NULL,
    [DefaultHttpTokenType]                  NVARCHAR (100) NOT NULL,
    [DefaultTokenLifetime]                  INT            NOT NULL,
    [MaximumTokenLifetime]                  INT            NOT NULL,
    [SsoCookieLifetime]                     INT            NOT NULL,
    [RequireEncryption]                     BIT            NOT NULL,
    [RequireRelyingPartyRegistration]       BIT            NOT NULL,
    [EnableClientCertificateAuthentication] BIT            NOT NULL,
    [EnforceUsersGroupMembership]           BIT            NOT NULL,
    [HttpPort]                              INT            NOT NULL,
    [HttpsPort]                             INT            NOT NULL,
    [DisableSSL]                            BIT            NOT NULL,
    [PublicHostName]                        NVARCHAR (500) NULL,
    CONSTRAINT [PK_GLOBALCONFIGURATION] PRIMARY KEY CLUSTERED ([Id] ASC)
);

