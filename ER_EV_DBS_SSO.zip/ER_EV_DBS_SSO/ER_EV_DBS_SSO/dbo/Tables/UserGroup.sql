﻿CREATE TABLE [dbo].[UserGroup] (
    [UserId]  INT NOT NULL,
    [GroupId] INT NOT NULL,
    CONSTRAINT [PK_USERGROUP] PRIMARY KEY CLUSTERED ([UserId] ASC, [GroupId] ASC),
    CONSTRAINT [FK_USERGROU_REF_USER__USER] FOREIGN KEY ([UserId]) REFERENCES [dbo].[User] ([Id]),
    CONSTRAINT [FK_USERGROU_REF_USERG_GROUP] FOREIGN KEY ([GroupId]) REFERENCES [dbo].[Group] ([Id])
);


GO
CREATE NONCLUSTERED INDEX [Index_FKs]
    ON [dbo].[UserGroup]([UserId] ASC, [GroupId] ASC);

