﻿CREATE TABLE [dbo].[SystemLog] (
    [Id]                INT             IDENTITY (1, 1) NOT NULL,
    [Type]              NVARCHAR (50)   NOT NULL,
    [Source]            NVARCHAR (50)   NOT NULL,
    [Category]          NVARCHAR (50)   NOT NULL,
    [OperatorName]      NVARCHAR (200)  NOT NULL,
    [OperationTime]     DATETIME        NOT NULL,
    [Operation]         NVARCHAR (200)  NOT NULL,
    [OperationObjectId] INT             NULL,
    [OperationObject]   NVARCHAR (1000) NULL,
    [Comment]           NVARCHAR (1000) NULL,
    [Data]              NTEXT           NULL,
    CONSTRAINT [PK_SYSTEMLOG] PRIMARY KEY CLUSTERED ([Id] ASC)
);


GO
CREATE NONCLUSTERED INDEX [Index_Id]
    ON [dbo].[SystemLog]([Id] ASC);

