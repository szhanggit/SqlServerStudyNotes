﻿CREATE TABLE [dbo].[Profile] (
    [Id]     INT             IDENTITY (1, 1) NOT NULL,
    [UserId] INT             NOT NULL,
    [Name]   NVARCHAR (2000) NOT NULL,
    [Value]  NVARCHAR (2000) NOT NULL,
    CONSTRAINT [PK_PROFILE] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_PROFILE_REFERENCE_USER] FOREIGN KEY ([UserId]) REFERENCES [dbo].[User] ([Id])
);

