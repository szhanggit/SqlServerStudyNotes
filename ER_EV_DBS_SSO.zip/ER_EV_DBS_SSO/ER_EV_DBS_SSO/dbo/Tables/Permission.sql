﻿CREATE TABLE [dbo].[Permission] (
    [Id]          INT             IDENTITY (1, 1) NOT NULL,
    [AppId]       INT             NOT NULL,
    [RoleId]      INT             NOT NULL,
    [OperationId] INT             NOT NULL,
    [ResourceId]  INT             NOT NULL,
    [Description] NVARCHAR (2000) NULL,
    CONSTRAINT [PK_PERMISSION] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_PERMISSI_REF_PERMI_OPERATIO] FOREIGN KEY ([OperationId]) REFERENCES [dbo].[Operation] ([Id]),
    CONSTRAINT [FK_PERMISSI_REF_PERMI_ROLE] FOREIGN KEY ([RoleId]) REFERENCES [dbo].[Role] ([Id]),
    CONSTRAINT [FK_PERMISSI_REFERENCE_APP] FOREIGN KEY ([AppId]) REFERENCES [dbo].[App] ([Id]),
    CONSTRAINT [FK_PERMISSI_REFERENCE_RESOURCE] FOREIGN KEY ([ResourceId]) REFERENCES [dbo].[Resource] ([Id])
);


GO
CREATE NONCLUSTERED INDEX [Index_Id]
    ON [dbo].[Permission]([Id] ASC);

