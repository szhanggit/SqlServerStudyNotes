﻿CREATE TABLE [dbo].[SystemError] (
    [Id]          INT            NOT NULL,
    [Source]      NVARCHAR (200) NULL,
    [CurrentUser] INT            NULL,
    [ErrorTime]   DATETIME       NULL,
    [Message]     NTEXT          NULL,
    [StackTrace]  NTEXT          NULL,
    [IP]          NVARCHAR (200) NULL,
    [UserAgent]   NVARCHAR (200) NULL,
    [OtherInfo]   NTEXT          NULL,
    CONSTRAINT [PK_SYSTEMERROR] PRIMARY KEY CLUSTERED ([Id] ASC)
);


GO
CREATE NONCLUSTERED INDEX [Index_Id]
    ON [dbo].[SystemError]([Id] ASC);

