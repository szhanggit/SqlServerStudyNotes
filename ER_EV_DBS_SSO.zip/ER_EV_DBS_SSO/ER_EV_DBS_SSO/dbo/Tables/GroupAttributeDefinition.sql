﻿CREATE TABLE [dbo].[GroupAttributeDefinition] (
    [Id]          INT             IDENTITY (1, 1) NOT NULL,
    [AppId]       INT             NOT NULL,
    [Name]        NVARCHAR (200)  NOT NULL,
    [DisplayName] NVARCHAR (200)  NOT NULL,
    [Description] NVARCHAR (2000) NULL,
    CONSTRAINT [PK_GROUPATTRIBUTEDEFINITION] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_GROUPATT_REFERENCE_APP] FOREIGN KEY ([AppId]) REFERENCES [dbo].[App] ([Id])
);

