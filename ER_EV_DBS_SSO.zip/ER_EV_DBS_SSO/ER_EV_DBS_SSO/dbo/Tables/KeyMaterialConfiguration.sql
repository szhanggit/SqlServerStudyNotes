﻿CREATE TABLE [dbo].[KeyMaterialConfiguration] (
    [Id]                        INT            IDENTITY (1, 1) NOT NULL,
    [SigningCertificateName]    NVARCHAR (200) NULL,
    [DecryptionCertificateName] NVARCHAR (500) NULL,
    [RSASigningKey]             NVARCHAR (500) NULL,
    [SymmetricSigningKey]       NVARCHAR (500) NULL,
    CONSTRAINT [PK_KEYMATERIALCONFIGURATION] PRIMARY KEY CLUSTERED ([Id] ASC)
);

