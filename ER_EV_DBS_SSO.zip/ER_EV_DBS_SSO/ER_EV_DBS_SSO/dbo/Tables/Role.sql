﻿CREATE TABLE [dbo].[Role] (
    [Id]          INT             IDENTITY (1, 1) NOT NULL,
    [Name]        NVARCHAR (200)  NOT NULL,
    [DisplayName] NVARCHAR (200)  NOT NULL,
    [Enabled]     BIT             DEFAULT ((1)) NOT NULL,
    [Description] NVARCHAR (2000) NULL,
    [IsGlobal]    BIT             DEFAULT ((0)) NOT NULL,
    [AppId]       INT             NULL,
    CONSTRAINT [PK_ROLE] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_ROLE_REFERENCE_APP] FOREIGN KEY ([AppId]) REFERENCES [dbo].[App] ([Id])
);


GO
CREATE NONCLUSTERED INDEX [Index_Id]
    ON [dbo].[Role]([Id] ASC);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'true = apply to all user', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Role', @level2type = N'COLUMN', @level2name = N'IsGlobal';

