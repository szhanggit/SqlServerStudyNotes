﻿CREATE TABLE [dbo].[Translation] (
    [Id]           INT             IDENTITY (1, 1) NOT NULL,
    [Lcid]         INT             NOT NULL,
    [LanguageCode] NVARCHAR (20)   NOT NULL,
    [Value]        NVARCHAR (1000) NOT NULL,
    CONSTRAINT [PK_TRANSLATION] PRIMARY KEY CLUSTERED ([Id] ASC)
);


GO
CREATE NONCLUSTERED INDEX [Index_Id]
    ON [dbo].[Translation]([Id] ASC);

