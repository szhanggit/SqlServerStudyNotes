﻿CREATE TABLE [dbo].[IdentityProvider] (
    [Id]                   INT            IDENTITY (1, 1) NOT NULL,
    [Name]                 NVARCHAR (200) NOT NULL,
    [DisplayName]          NVARCHAR (200) NOT NULL,
    [Type]                 INT            NOT NULL,
    [ShowInHrdSelection]   BIT            NOT NULL,
    [WSFederationEndpoint] NVARCHAR (500) NULL,
    [IssuerThumbprint]     NVARCHAR (500) NULL,
    [ClientID]             NVARCHAR (200) NULL,
    [ClientSecret]         NVARCHAR (500) NULL,
    [OAuth2ProviderType]   INT            NULL,
    [Enabled]              BIT            NOT NULL,
    CONSTRAINT [PK_IDENTITYPROVIDER] PRIMARY KEY CLUSTERED ([Id] ASC)
);

