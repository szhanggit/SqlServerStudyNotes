﻿CREATE TABLE [dbo].[WSTrustConfiguration] (
    [Id]                                    INT IDENTITY (1, 1) NOT NULL,
    [Enabled]                               BIT NOT NULL,
    [EnableMessageSecurity]                 BIT NOT NULL,
    [EnableMixedModeSecurity]               BIT NOT NULL,
    [EnableClientCertificateAuthentication] BIT NOT NULL,
    [EnableFederatedAuthentication]         BIT NOT NULL,
    [EnableDelegation]                      BIT NOT NULL,
    CONSTRAINT [PK_WSTRUSTCONFIGURATION] PRIMARY KEY CLUSTERED ([Id] ASC)
);

