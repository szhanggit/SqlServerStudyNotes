﻿CREATE TABLE [dbo].[ResourceSetting] (
    [Id]          INT             IDENTITY (1, 1) NOT NULL,
    [ResourceId]  INT             NOT NULL,
    [Name]        NVARCHAR (200)  NULL,
    [DisplayName] NVARCHAR (200)  NOT NULL,
    [Value]       NTEXT           NULL,
    [Description] NVARCHAR (2000) NULL,
    CONSTRAINT [PK_RESOURCESETTING] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_RESOURCE_REF_RESOU_RESOURCE] FOREIGN KEY ([ResourceId]) REFERENCES [dbo].[Resource] ([Id])
);


GO
CREATE NONCLUSTERED INDEX [Index_Id]
    ON [dbo].[ResourceSetting]([Id] ASC);

