﻿CREATE TABLE [dbo].[RelyingParty] (
    [Id]                     INT            IDENTITY (1, 1) NOT NULL,
    [Name]                   NVARCHAR (200) NOT NULL,
    [Enabled]                BIT            NOT NULL,
    [Realm]                  NVARCHAR (200) NOT NULL,
    [TokenType]              INT            NULL,
    [TokenLifeTime]          INT            NOT NULL,
    [ReplyTo]                NVARCHAR (500) NULL,
    [EncryptingCertificate]  NVARCHAR (MAX) NULL,
    [SymmetricSigningKey]    NVARCHAR (500) NULL,
    [ExtraData1]             NVARCHAR (500) NULL,
    [ExtraData2]             NVARCHAR (500) NULL,
    [ExtraData3]             NVARCHAR (500) NULL,
    [EnableCustomSignInPage] BIT            DEFAULT ((0)) NOT NULL,
    [CustomSignInPage]       NTEXT          NULL,
    CONSTRAINT [PK_RELYINGPARTY] PRIMARY KEY CLUSTERED ([Id] ASC)
);

