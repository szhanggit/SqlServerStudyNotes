﻿CREATE TABLE [dbo].[DiagnosticsConfiguration] (
    [Id]                             INT IDENTITY (1, 1) NOT NULL,
    [EnableFederationMessageTracing] BIT NOT NULL,
    CONSTRAINT [PK_DIAGNOSTICSCONFIGURATION] PRIMARY KEY CLUSTERED ([Id] ASC)
);

