﻿CREATE TABLE [dbo].[GroupAttribute] (
    [Id]                         INT             IDENTITY (1, 1) NOT NULL,
    [GroupId]                    INT             NOT NULL,
    [GroupAttributeDefinitionId] INT             NOT NULL,
    [Value]                      NVARCHAR (1000) NOT NULL,
    CONSTRAINT [PK_GROUPATTRIBUTE] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_GROUPATT_REFERENCE_GROUP] FOREIGN KEY ([GroupId]) REFERENCES [dbo].[Group] ([Id]) ON DELETE CASCADE,
    CONSTRAINT [FK_GROUPATT_REFERENCE_GROUPATT] FOREIGN KEY ([GroupAttributeDefinitionId]) REFERENCES [dbo].[GroupAttributeDefinition] ([Id]) ON DELETE CASCADE
);

