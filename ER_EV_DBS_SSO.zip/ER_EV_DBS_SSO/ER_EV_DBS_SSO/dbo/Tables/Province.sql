﻿CREATE TABLE [dbo].[Province] (
    [Id]            INT            IDENTITY (1, 1) NOT NULL,
    [CountryId]     INT            NULL,
    [Name]          NVARCHAR (200) NULL,
    [TranslationId] INT            NULL,
    CONSTRAINT [PK_PROVINCE] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_PROVINCE_REF_PROVI_COUNTRY] FOREIGN KEY ([CountryId]) REFERENCES [dbo].[Country] ([Id])
);


GO
CREATE NONCLUSTERED INDEX [Index_Id]
    ON [dbo].[Province]([Id] ASC);

