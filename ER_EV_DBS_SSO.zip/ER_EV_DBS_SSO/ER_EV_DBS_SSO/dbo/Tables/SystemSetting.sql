﻿CREATE TABLE [dbo].[SystemSetting] (
    [Id]          INT             IDENTITY (1, 1) NOT NULL,
    [Key]         NVARCHAR (200)  NULL,
    [Value]       NTEXT           NULL,
    [Description] NVARCHAR (2000) NULL,
    CONSTRAINT [PK_SYSTEMSETTING] PRIMARY KEY CLUSTERED ([Id] ASC)
);


GO
CREATE NONCLUSTERED INDEX [Index_Id]
    ON [dbo].[SystemSetting]([Id] ASC);

