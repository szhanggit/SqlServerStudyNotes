﻿CREATE TABLE [dbo].[Group] (
    [Id]          INT             IDENTITY (1, 1) NOT NULL,
    [ParentId]    INT             NULL,
    [AppId]       INT             NOT NULL,
    [Name]        NVARCHAR (200)  NOT NULL,
    [DisplayName] NVARCHAR (200)  NOT NULL,
    [SortIndex]   INT             DEFAULT ((0)) NOT NULL,
    [Description] NVARCHAR (2000) NULL,
    CONSTRAINT [PK_GROUP] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_GROUP_REFERENCE_APP] FOREIGN KEY ([AppId]) REFERENCES [dbo].[App] ([Id]),
    CONSTRAINT [FK_GROUP_REFERENCE_GROUP] FOREIGN KEY ([ParentId]) REFERENCES [dbo].[Group] ([Id])
);


GO
CREATE NONCLUSTERED INDEX [Index_Id]
    ON [dbo].[Group]([Id] ASC);

