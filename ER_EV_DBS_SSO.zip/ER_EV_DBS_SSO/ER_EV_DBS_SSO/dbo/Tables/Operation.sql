﻿CREATE TABLE [dbo].[Operation] (
    [Id]          INT             IDENTITY (1, 1) NOT NULL,
    [Name]        NVARCHAR (200)  NOT NULL,
    [DisplayName] NVARCHAR (200)  NULL,
    [Description] NVARCHAR (2000) NULL,
    [AppId]       INT             NOT NULL,
    CONSTRAINT [PK_OPERATION] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_OPERATIO_REFERENCE_APP] FOREIGN KEY ([AppId]) REFERENCES [dbo].[App] ([Id])
);


GO
CREATE NONCLUSTERED INDEX [Index_Id]
    ON [dbo].[Operation]([Id] ASC);

