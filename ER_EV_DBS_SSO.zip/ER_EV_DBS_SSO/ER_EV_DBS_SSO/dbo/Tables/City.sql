﻿CREATE TABLE [dbo].[City] (
    [Id]            INT IDENTITY (1, 1) NOT NULL,
    [ProvinceId]    INT NULL,
    [Name]          INT NULL,
    [TranslationId] INT NULL,
    CONSTRAINT [PK_CITY] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_CITY_REF_CITY__PROVINCE] FOREIGN KEY ([ProvinceId]) REFERENCES [dbo].[Province] ([Id])
);


GO
CREATE NONCLUSTERED INDEX [Index_Id]
    ON [dbo].[City]([Id] ASC);

