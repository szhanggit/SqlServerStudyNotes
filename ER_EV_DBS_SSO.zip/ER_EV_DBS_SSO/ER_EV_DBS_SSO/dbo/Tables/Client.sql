﻿CREATE TABLE [dbo].[Client] (
    [Id]                     INT            IDENTITY (1, 1) NOT NULL,
    [Name]                   NVARCHAR (200) NOT NULL,
    [Description]            NVARCHAR (500) NULL,
    [ClientId]               NVARCHAR (200) NOT NULL,
    [ClientSecret]           NVARCHAR (500) NOT NULL,
    [RedirectUri]            NVARCHAR (500) NOT NULL,
    [AllowRefreshToken]      BIT            NOT NULL,
    [AllowImplicitFlow]      BIT            NOT NULL,
    [AllowResourceOwnerFlow] BIT            NOT NULL,
    [AllowCodeFlow]          BIT            NOT NULL,
    CONSTRAINT [PK_CLIENT] PRIMARY KEY CLUSTERED ([Id] ASC)
);

