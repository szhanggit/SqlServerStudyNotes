﻿CREATE TABLE [dbo].[CodeToken] (
    [Id]        INT            IDENTITY (1, 1) NOT NULL,
    [Code]      NVARCHAR (200) NOT NULL,
    [ClientId]  INT            NOT NULL,
    [UserName]  NVARCHAR (200) NOT NULL,
    [Scope]     NVARCHAR (100) NOT NULL,
    [Type]      INT            NOT NULL,
    [TimeStamp] DATETIME       NOT NULL,
    CONSTRAINT [PK_CODETOKEN] PRIMARY KEY CLUSTERED ([Id] ASC)
);

