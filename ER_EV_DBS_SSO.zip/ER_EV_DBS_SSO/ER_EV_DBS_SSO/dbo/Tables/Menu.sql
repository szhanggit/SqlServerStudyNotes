﻿CREATE TABLE [dbo].[Menu] (
    [Id]              INT             IDENTITY (1, 1) NOT NULL,
    [ParentId]        INT             NULL,
    [Type]            INT             NOT NULL,
    [Name]            NVARCHAR (50)   NOT NULL,
    [DisplayName]     NVARCHAR (200)  NOT NULL,
    [SortIndex]       INT             DEFAULT ((0)) NOT NULL,
    [Description]     NVARCHAR (500)  NULL,
    [Url]             NVARCHAR (1000) NOT NULL,
    [Target]          NVARCHAR (20)   DEFAULT ('_self') NOT NULL,
    [NeedTranslation] BIT             DEFAULT ((0)) NOT NULL,
    [Tooltip]         NVARCHAR (200)  NULL,
    [Enabled]         BIT             DEFAULT ((1)) NOT NULL,
    [AppId]           INT             NOT NULL,
    CONSTRAINT [PK_MENU] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_MENU_REFERENCE_APP] FOREIGN KEY ([AppId]) REFERENCES [dbo].[App] ([Id]),
    CONSTRAINT [FK_MENU_REFERENCE_MENU] FOREIGN KEY ([ParentId]) REFERENCES [dbo].[Menu] ([Id])
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = '1 - TopMenu
   2 - LeftMenu', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'Menu', @level2type = N'COLUMN', @level2name = N'Type';

