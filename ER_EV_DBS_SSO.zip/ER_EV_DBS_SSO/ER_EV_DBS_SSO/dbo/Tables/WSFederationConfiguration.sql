﻿CREATE TABLE [dbo].[WSFederationConfiguration] (
    [Id]                        INT IDENTITY (1, 1) NOT NULL,
    [Enabled]                   BIT NOT NULL,
    [EnableAuthentication]      BIT NOT NULL,
    [EnableFederation]          BIT NOT NULL,
    [EnableHrd]                 BIT NOT NULL,
    [AllowReplyTo]              BIT NOT NULL,
    [RequireReplyToWithinRealm] BIT NOT NULL,
    [RequireSslForReplyTo]      BIT NOT NULL,
    CONSTRAINT [PK_WSFEDERATIONCONFIGURATION] PRIMARY KEY CLUSTERED ([Id] ASC)
);

