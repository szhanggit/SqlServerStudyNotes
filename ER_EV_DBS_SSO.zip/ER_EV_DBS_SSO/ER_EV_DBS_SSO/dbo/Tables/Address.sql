﻿CREATE TABLE [dbo].[Address] (
    [Id]           INT            IDENTITY (1, 1) NOT NULL,
    [CityId]       INT            NULL,
    [AdrdessLine1] NVARCHAR (200) NULL,
    [AddressLine2] NVARCHAR (200) NULL,
    [PostCode]     NVARCHAR (100) NULL,
    CONSTRAINT [PK_ADDRESS] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_ADDRESS_REF_ADDRE_CITY] FOREIGN KEY ([CityId]) REFERENCES [dbo].[City] ([Id]) ON DELETE SET NULL ON UPDATE SET NULL
);


GO
CREATE NONCLUSTERED INDEX [Index_Id]
    ON [dbo].[Address]([Id] ASC);

