﻿CREATE TABLE [dbo].[Resource] (
    [Id]          INT             IDENTITY (1, 1) NOT NULL,
    [ModuleId]    INT             NULL,
    [Name]        NVARCHAR (200)  NOT NULL,
    [DisplayName] NVARCHAR (200)  NOT NULL,
    [Description] NVARCHAR (2000) NULL,
    [AppId]       INT             NOT NULL,
    CONSTRAINT [PK_RESOURCE] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_RESOURCE_REFERENCE_APP] FOREIGN KEY ([AppId]) REFERENCES [dbo].[App] ([Id]),
    CONSTRAINT [FK_RESOURCE_REFERENCE_MODULE] FOREIGN KEY ([ModuleId]) REFERENCES [dbo].[Module] ([Id])
);


GO
CREATE NONCLUSTERED INDEX [Index_Id]
    ON [dbo].[Resource]([Id] ASC);

