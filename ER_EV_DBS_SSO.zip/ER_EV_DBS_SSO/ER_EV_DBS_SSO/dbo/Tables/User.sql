﻿CREATE TABLE [dbo].[User] (
    [Id]             INT             IDENTITY (1, 1) NOT NULL,
    [UserName]       NVARCHAR (200)  NOT NULL,
    [Password]       NVARCHAR (1000) NOT NULL,
    [Email]          NVARCHAR (500)  NOT NULL,
    [Type]           INT             NOT NULL,
    [Enabled]        BIT             NOT NULL,
    [LastLoginTime]  DATETIME        NULL,
    [FirstName]      NVARCHAR (200)  NULL,
    [LastName]       NVARCHAR (200)  NULL,
    [Gender]         INT             NULL,
    [Birthday]       DATETIME        NULL,
    [Telephone]      NVARCHAR (200)  NULL,
    [Title]          NVARCHAR (100)  NULL,
    [DisplayName]    NVARCHAR (100)  NULL,
    [Alias]          NVARCHAR (100)  NULL,
    [Company]        NVARCHAR (100)  NULL,
    [Address]        NVARCHAR (500)  NULL,
    [Department]     NVARCHAR (200)  NULL,
    [Country]        NVARCHAR (50)   NULL,
    [City]           NVARCHAR (50)   NULL,
    [State]          NVARCHAR (50)   NULL,
    [Office]         NVARCHAR (200)  NULL,
    [ZipCode]        NVARCHAR (50)   NULL,
    [Mobile]         NVARCHAR (200)  NULL,
    [CreationTime]   DATETIME        NULL,
    [LastUpdateTime] DATETIME        NULL,
    CONSTRAINT [PK_USER] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [AK_KEY_USERNAME_USER] UNIQUE NONCLUSTERED ([UserName] ASC)
);


GO
CREATE NONCLUSTERED INDEX [Index_Id]
    ON [dbo].[User]([Id] ASC);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = '1 = Male
   2 = Female
   3 = Other', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'User', @level2type = N'COLUMN', @level2name = N'Gender';

